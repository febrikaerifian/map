## Indonesia Map for jVector Map
Custom map i made and use for [Selusur Nusantara](https://www.selusurnusantara.com) project.

![enter image description here](http://www.nge-blog-di.selusurnusantara.com/content/screenshoot.png "Screenshoot")
